import random

# Constants for the game
EMPTY = 0
BLACK = 1
WHITE = 2
BOARD_SIZE = 8

DIRECTIONS = [(0, 1), (0, -1), (1, 0), (-1, 0)]

class Othello:
    def __init__(self):
        self.board = [[EMPTY] * BOARD_SIZE for _ in range(BOARD_SIZE)]
        self.board[3][3] = WHITE
        self.board[3][4] = BLACK
        self.board[4][3] = BLACK
        self.board[4][4] = WHITE
        self.current_player = BLACK
        self.valid_moves = self.get_valid_moves()

    def get_valid_moves(self):
        valid_moves = []
        for row in range(BOARD_SIZE):
            for col in range(BOARD_SIZE):
                if self.board[row][col] == EMPTY and self.is_valid_move(row, col):
                    valid_moves.append((row, col))
        return valid_moves

    def is_valid_move(self, row, col):
        if self.board[row][col] != EMPTY:
            return False
        for dr, dc in DIRECTIONS:
            r, c = row + dr, col + dc
            if not (0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE):
                continue
            if self.board[r][c] == EMPTY or self.board[r][c] == self.current_player:
                continue
            while 0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE and self.board[r][c] != EMPTY:
                if self.board[r][c] == self.current_player:
                    return True
                r, c = r + dr, c + dc
        return False

    def make_move(self, row, col):
        if (row, col) not in self.valid_moves:
            return False
        self.board[row][col] = self.current_player
        self.flip_tiles(row, col)
        self.current_player = WHITE if self.current_player == BLACK else BLACK
        self.valid_moves = self.get_valid_moves()
        return True

    def flip_tiles(self, row, col):
        for dr, dc in DIRECTIONS:
            r, c = row + dr, col + dc
            to_flip = []
            while 0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE and self.board[r][c] != EMPTY:
                if self.board[r][c] == self.current_player:
                    for tr, tc in to_flip:
                        self.board[tr][tc] = self.current_player
                    break
                to_flip.append((r, c))
                r, c = r + dr, c + dc

    def game_over(self):
        return len(self.valid_moves) == 0

    def count_tiles(self):
        black_count = sum(row.count(BLACK) for row in self.board)
        white_count = sum(row.count(WHITE) for row in self.board)
        return black_count, white_count

class ConsoleGame:
    def __init__(self, difficulty):
        self.othello = Othello()
        self.difficulty = difficulty

    def play(self):
        while not self.othello.game_over():
            self.othello.valid_moves = self.othello.get_valid_moves()
            self.print_board()
            if self.othello.current_player == BLACK:
                print("Black's Turn")
                self.player_move()
            else:
                print("White's Turn")
                if self.difficulty == "Human":
                    self.player_move()
                else:
                    self.computer_move()
        self.end_game()

    def player_move(self):
        print("Valid Moves: ")
        for idx, move in enumerate(self.othello.valid_moves):
            print(f"{idx}- {move}")
        while True:
            try:
                choice = int(input("Enter your choice: "))
                if 0 <= choice < len(self.othello.valid_moves):
                    row, col = self.othello.valid_moves[choice]
                    self.othello.make_move(row, col)
                    break
                else:
                    print("Invalid choice. Please enter a valid index.")
            except ValueError:
                print("Invalid input. Please enter an integer.")

    def computer_move(self):
        if self.difficulty == "Easy":
            depth = 1
        elif self.difficulty == "Medium":
            depth = 3
        elif self.difficulty == "Hard":
            depth = 5
        else:
            depth = 3
        best_move = self.find_best_move(self.othello, depth)
        self.othello.make_move(*best_move)

    def find_best_move(self, othello, depth):
        # The minimax algorithm with alpha-beta pruning
        def alphabeta(node, depth, alpha, beta, maximizing_player):
            if depth == 0 or node.game_over():
                return self.evaluate(node)
            if maximizing_player:
                max_eval = float('-inf')
                for move in node.valid_moves:
                    child = self.get_child(node, move)
                    eval = alphabeta(child, depth - 1, alpha, beta, False)
                    max_eval = max(max_eval, eval)
                    alpha = max(alpha, eval)
                    if beta <= alpha:
                        break
                return max_eval
            else:
                min_eval = float('inf')
                for move in node.valid_moves:
                    child = self.get_child(node, move)
                    eval = alphabeta(child, depth - 1, alpha, beta, True)
                    min_eval = min(min_eval, eval)
                    beta = min(beta, eval)
                    if beta <= alpha:
                        break
                return min_eval

        best_move = None
        max_eval = float('-inf')
        for move in othello.valid_moves:
            child = self.get_child(othello, move)
            eval = alphabeta(child, depth - 1, float('-inf'), float('inf'), False)
            if eval > max_eval:
                max_eval = eval
                best_move = move
        return best_move

    def get_child(self, othello, move):
        child = Othello()
        child.board = [row[:] for row in othello.board]
        child.current_player = othello.current_player
        child.make_move(*move)
        return child

    def evaluate(self, othello):
        black_count, white_count = othello.count_tiles()
        if othello.current_player == BLACK:
            return black_count - white_count
        else:
            return white_count - black_count

    def print_board(self):
        print("  ", end="")
        for i in range(BOARD_SIZE):
            print(i, end=" ")
        print()
        for i, row in enumerate(self.othello.board):
            print(i, end=" ")
            for col in row:
                if col == BLACK:
                    print("B", end=" ")
                elif col == WHITE:
                    print("W", end=" ")
                else:
                    print(".", end=" ")
            print()

    def end_game(self):
        black_count, white_count = self.othello.count_tiles()
        if black_count > white_count:
            winner = "Black"
        elif white_count > black_count:
            winner = "White"
        else:
            winner = "Tie"
        print(f"The winner is {winner}!")

if __name__ == "__main__":
    while True:
        choice = input("For GUI press 1, for console press 2: ")
        if choice == "1":

            import tkinter as tk
            from tkinter import messagebox

            difficulty = input("Select difficulty (Easy, Medium, Hard): ")

            class GUI:
                def __init__(self, master, difficulty):
                    self.master = master
                    self.difficulty = difficulty
                    self.othello = Othello()
                    self.create_board()

                def create_board(self):
                    self.buttons = [[None] * BOARD_SIZE for _ in range(BOARD_SIZE)]
                    for row in range(BOARD_SIZE):
                        for col in range(BOARD_SIZE):
                            self.buttons[row][col] = tk.Button(self.master, command=lambda row=row, col=col: self.make_move(row, col), width=4, height=2)
                            self.buttons[row][col].grid(row=row, column=col)
                    self.update_board()

                def update_board(self):
                    for row in range(BOARD_SIZE):
                        for col in range(BOARD_SIZE):
                            if self.othello.board[row][col] == BLACK:
                                self.buttons[row][col].config(bg='black')
                            elif self.othello.board[row][col] == WHITE:
                                self.buttons[row][col].config(bg='white')
                            else:
                                self.buttons[row][col].config(bg='green')

                def make_move(self, row, col):
                    if self.othello.make_move(row, col):
                        self.update_board()
                        if self.othello.game_over():
                            self.end_game()
                            return
                        if self.othello.current_player == WHITE:
                            self.computer_move()

                def computer_move(self):
                    if self.difficulty == "Easy":
                        depth = 1
                    elif self.difficulty == "Medium":
                        depth = 3
                    elif self.difficulty == "Hard":
                        depth = 5
                    else:
                        depth = 3  # Default to medium level
                    best_move = self.find_best_move(self.othello, depth)
                    self.make_move(*best_move)

                def find_best_move(self, othello, depth):
                    def alphabeta(node, depth, alpha, beta, maximizing_player):
                        if depth == 0 or node.game_over():
                            return self.evaluate(node)
                        if maximizing_player:
                            max_eval = float('-inf')
                            for move in node.valid_moves:
                                child = self.get_child(node, move)
                                eval = alphabeta(child, depth - 1, alpha, beta, False)
                                max_eval = max(max_eval, eval)
                                alpha = max(alpha, eval)
                                if beta <= alpha:
                                    break
                            return max_eval
                        else:
                            min_eval = float('inf')
                            for move in node.valid_moves:
                                child = self.get_child(node, move)
                                eval = alphabeta(child, depth - 1, alpha, beta, True)
                                min_eval = min(min_eval, eval)
                                beta = min(beta, eval)
                                if beta <= alpha:
                                    break
                            return min_eval

                    best_move = None
                    max_eval = float('-inf')
                    for move in othello.valid_moves:
                        child = self.get_child(othello, move)
                        eval = alphabeta(child, depth - 1, float('-inf'), float('inf'), False)
                        if eval > max_eval:
                            max_eval = eval
                            best_move = move
                    return best_move

                def get_child(self, othello, move):
                    child = Othello()
                    child.board = [row[:] for row in othello.board]
                    child.current_player = othello.current_player
                    child.make_move(*move)
                    return child

                def evaluate(self, othello):
                    black_count, white_count = othello.count_tiles()
                    if othello.current_player == BLACK:
                        return black_count - white_count
                    else:
                        return white_count - black_count

                def end_game(self):
                    black_count, white_count = self.othello.count_tiles()
                    if black_count > white_count:
                        winner = "Black"
                    elif white_count > black_count:
                        winner = "White"
                    else:
                        winner = "Tie"
                    messagebox.showinfo("Game Over", f"The winner is {winner}!")

            root = tk.Tk()
            root.title("Othello")
            gui = GUI(root, difficulty)
            root.mainloop()
            break
        elif choice == "2":
            difficulty = input("Enter difficulty (Easy, Medium, Hard): ")
            game = ConsoleGame(difficulty)
            game.play()
            break
        else:
            print("Invalid choice. Please enter 1 or 2.")